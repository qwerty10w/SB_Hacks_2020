package com.example.qwerty10w.sb_hacks_2020_app;

public class Contact {
    public String Fname;
    public String Lname;
    public Long phoneNum;

    public Contact(String F, String L, Long Num){
        this.Fname = F;
        this.Lname = L;
        this.phoneNum = Num;
    }
}
