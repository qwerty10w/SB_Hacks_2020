package com.example.qwerty10w.sb_hacks_2020_app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ContactPage extends AppCompatActivity {
    public TextView Name;
    public TextView PNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_page);
        long Phone = getIntent().getLongExtra("Phone", 0L);
        String FName = getIntent().getStringExtra("Fname");
        String LName = getIntent().getStringExtra("Lname");

        Name = (TextView)findViewById(R.id.textView_name);
        Name.setText(FName + " " + LName);

        PNum = (TextView)findViewById(R.id.textView_number);
        PNum.setText(Long.toString(Phone));

    }
}
