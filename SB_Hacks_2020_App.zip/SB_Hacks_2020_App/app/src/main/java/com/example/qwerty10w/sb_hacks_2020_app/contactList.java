package com.example.qwerty10w.sb_hacks_2020_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
//import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import androidx.appcompat.app.AppCompatActivity;

public class contactList extends AppCompatActivity {
    //public List<Contact> cList;
    //public String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Contact/Contacts.csv";
    //File file = new File(path);
    //public String cList[] = Load(file);
    //LinearLayout linear = (LinearLayout) findViewById(R.id.button_layout);

    public Button contact1;
    public Button contact2;
    public Button contact3;
    public Button contact4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        contact1 = (Button)findViewById(R.id.button_harry);
        contact2 = (Button)findViewById(R.id.button_hermione);
        contact3 = (Button)findViewById(R.id.button_ron);
        contact4 = (Button)findViewById(R.id.button_albus);

        contact1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(contactList.this, ContactPage.class);
                        Contact person = new Contact("Harry","Potter", 4088960412L );
                        intent.putExtra("Fname", person.Fname);
                        intent.putExtra("Lname", person.Lname);
                        intent.putExtra("Phone", person.phoneNum);
                        startActivity(intent);
                    }
                }
        );

        contact2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(contactList.this, ContactPage.class);
                        Contact person = new Contact("Hermione", "Granger", 555555555L);
                        intent.putExtra("Fname", person.Fname);
                        intent.putExtra("Lname", person.Lname);
                        intent.putExtra("Phone", person.phoneNum);
                        startActivity(intent);
                    }
                }
        );

        contact3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(contactList.this, ContactPage.class);
                        Contact person = new Contact("Ronald", "Weasley", 1234634665L);
                        intent.putExtra("Fname", person.Fname);
                        intent.putExtra("Lname", person.Lname);
                        intent.putExtra("Phone", person.phoneNum);
                        startActivity(intent);
                    }
                }
        );

        contact4.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(contactList.this, ContactPage.class);
                        Contact person = new Contact("Albus", "Dumbledore", 1234567899L);
                        intent.putExtra("Fname", person.Fname);
                        intent.putExtra("Lname", person.Lname);
                        intent.putExtra("Phone", person.phoneNum);
                        startActivity(intent);
                    }
                }
        );



        //readContacts(cList);

//        for (String entry : cList) {
//            int i = 1;
//            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
//                    LinearLayout.LayoutParams.MATCH_PARENT,
//                    LinearLayout.LayoutParams.WRAP_CONTENT);
//            Button btn = new Button(this);
//            btn.setId(i);
//            final int id_ = btn.getId();
//            btn.setText(entry);
//            linear.addView(btn, params);
//            i++;
//        }

    }

    private String readFromFile(Context context) {

        String ret = "";

        try {
            InputStream inputStream = context.openFileInput("Contacts.csv");

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ((receiveString = bufferedReader.readLine()) != null) {
                    stringBuilder.append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        } catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }

    public static String[] Load(File file) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader br = new BufferedReader(isr);

        String test;
        int anzahl = 0;
        try {
            while ((test = br.readLine()) != null) {
                anzahl++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            fis.getChannel().position(0);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] array = new String[anzahl];

        String line;
        int i = 0;
        try {
            while ((line = br.readLine()) != null) {
                array[i] = line;
                i++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return array;
    }
}