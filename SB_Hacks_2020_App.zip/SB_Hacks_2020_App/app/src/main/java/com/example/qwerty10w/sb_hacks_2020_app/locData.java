package com.example.qwerty10w.sb_hacks_2020_app;

public class locData {
    public int ID;
    public double lat;
    public double lon;

    public locData(){}

    public locData(int id, double lat, double lon){
        this.ID = id;
        this.lat = lat;
        this.lon = lon;
    }
}
