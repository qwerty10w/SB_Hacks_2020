package com.example.qwerty10w.sb_hacks_2020_app;

public class Account {
    public String userName;
    public String Name;
    public int ID;

    public Account(){}

    public Account(String u, String n, int id){
        this.userName = u;
        this.Name = n;
        this.ID = id;
    }
}

